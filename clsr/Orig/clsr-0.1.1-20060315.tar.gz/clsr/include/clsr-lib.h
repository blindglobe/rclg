
unsigned int test_sexp_type (SEXP obj);
char* test_sexp_string  (SEXP obj);
void test_me();

